﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiMiniMarket.Models;
using Microsoft.Data.SqlClient;
using System.Net;

namespace ApiMiniMarket.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class productoController : ControllerBase
    {
        private readonly BDMiniMarketContext _context;

        public productoController(BDMiniMarketContext context)
        {
            _context = context;
        }

        // GET: api/producto
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Tbproducto>>> GetTbproductos()
        {
            return await _context.Tbproductos.ToListAsync();
        }

        // GET: api/producto/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Tbproducto>> GetTbproducto(int id)
        {
            var tbproducto = await _context.Tbproductos.FindAsync(id);

            if (tbproducto == null)
            {
                return NotFound();
            }

            return tbproducto;
        }

        // PUT: api/producto/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTbproducto(int id, Tbproducto tbproducto)
        {
            if (id != tbproducto.Id)
            {
                return BadRequest();
            }

            _context.Entry(tbproducto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TbproductoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/producto
        [HttpPost]
        public async Task<ActionResult<Tbproducto>> PostTbproducto(Tbproducto tbproducto)
        {
            _context.Tbproductos.Add(tbproducto);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTbproducto", new { id = tbproducto.Id }, tbproducto);
        }


        [HttpPost("{consultar}")]
        public async Task<ActionResult<IEnumerable<Tbproducto>>> consultar(string productoconsult)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    List<Tbproducto> listaproducto = new List<Tbproducto>();
                    listaproducto = _context.Tbproductos.FromSqlRaw("EXECUTE SpConsultarProducto {0}", productoconsult).ToList();
                    transaction.Commit();

                    var resul = new
                    {
                        mensaje = "",
                        estado = true
                    };

                    return Ok(listaproducto);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    var myError = new
                    {
                        mensaje = "Error",
                        estado = false
                    };

                    return NoContent();
                }
            }
        }

        // DELETE: api/producto/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Tbproducto>> DeleteTbproducto(int id)
        {
            var tbproducto = await _context.Tbproductos.FindAsync(id);
            if (tbproducto == null)
            {
                return NotFound();
            }

            _context.Tbproductos.Remove(tbproducto);
            await _context.SaveChangesAsync();

            return tbproducto;
        }

        private bool TbproductoExists(int id)
        {
            return _context.Tbproductos.Any(e => e.Id == id);
        }
    }
}
