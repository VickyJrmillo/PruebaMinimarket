﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ApiMiniMarket.Models
{
    public partial class Tbproducto
    {
        public int Id { get; set; }
        public string NombreProducto { get; set; }
        public int Cantidad { get; set; }
        public double PrecioUnitario { get; set; }
        public string Medida { get; set; }
        public int Idproveedor { get; set; }
        public int Idmarca { get; set; }
        public int IdcategoriaProducto { get; set; }
    }
}
