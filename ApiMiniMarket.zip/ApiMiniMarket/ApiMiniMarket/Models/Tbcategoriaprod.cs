﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ApiMiniMarket.Models
{
    public partial class Tbcategoriaprod
    {
        public int Id { get; set; }
        public string Categoria { get; set; }
    }
}
