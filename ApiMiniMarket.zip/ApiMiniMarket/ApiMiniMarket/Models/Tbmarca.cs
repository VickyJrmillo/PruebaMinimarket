﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ApiMiniMarket.Models
{
    public partial class Tbmarca
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
