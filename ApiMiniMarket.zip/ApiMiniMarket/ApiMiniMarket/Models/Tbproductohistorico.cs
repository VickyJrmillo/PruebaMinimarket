﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ApiMiniMarket.Models
{
    public partial class Tbproductohistorico
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int Idproducto { get; set; }
        public string Nombreprod { get; set; }
        public int Cantidad { get; set; }
        public double PrecioUnitario { get; set; }
        public string Proveedor { get; set; }
        public string Marca { get; set; }
        public string Medida { get; set; }
        public string Categoriaprod { get; set; }
        public string Accion { get; set; }
    }
}
