﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ApiMiniMarket.Models
{
    public partial class Tbproveedor
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Ruc { get; set; }
        public string Empresa { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string Direccion { get; set; }
    }
}
