﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace ApiMiniMarket.Models
{
    public partial class BDMiniMarketContext : DbContext
    {
        public BDMiniMarketContext()
        {
        }

        public BDMiniMarketContext(DbContextOptions<BDMiniMarketContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Tbcategoriaprod> Tbcategoriaprods { get; set; }
        public virtual DbSet<Tbmarca> Tbmarcas { get; set; }
        public virtual DbSet<Tbproducto> Tbproductos { get; set; }
        public virtual DbSet<Tbproductohistorico> Tbproductohistoricos { get; set; }
        public virtual DbSet<Tbproveedor> Tbproveedors { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=localhost;Database=BDMiniMarket;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Modern_Spanish_CI_AS");

            modelBuilder.Entity<Tbcategoriaprod>(entity =>
            {
                entity.ToTable("tbcategoriaprod");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Categoria)
                    .IsRequired()
                    .HasMaxLength(75);
            });

            modelBuilder.Entity<Tbmarca>(entity =>
            {
                entity.ToTable("tbmarca");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Tbproducto>(entity =>
            {
                entity.ToTable("tbproducto");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdcategoriaProducto).HasColumnName("IDCategoriaProducto");

                entity.Property(e => e.Idmarca).HasColumnName("IDMarca");

                entity.Property(e => e.Idproveedor).HasColumnName("IDProveedor");

                entity.Property(e => e.Medida)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.NombreProducto)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Tbproductohistorico>(entity =>
            {
                entity.ToTable("tbproductohistorico");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Accion)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Categoriaprod)
                    .IsRequired()
                    .HasMaxLength(75);

                entity.Property(e => e.Fecha).HasColumnType("datetime");

                entity.Property(e => e.Idproducto).HasColumnName("IDProducto");

                entity.Property(e => e.Marca)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Medida)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Nombreprod)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Proveedor)
                    .IsRequired()
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<Tbproveedor>(entity =>
            {
                entity.ToTable("tbproveedor");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Correo)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Direccion)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.Empresa)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.Ruc)
                    .IsRequired()
                    .HasMaxLength(13)
                    .HasColumnName("RUC");

                entity.Property(e => e.Telefono)
                    .IsRequired()
                    .HasMaxLength(10);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
